<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_transaksi extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_transaksi');
    }
    public function index()
    {
        $data['transaksi'] = $this->M_transaksi->get_all();
        $this->load->view('viewTransaksi', $data);
    }

    public function createtransaksi(){
        $this->load->view('createTransaksi');
    }

    public function addtransaksi(){
        $data = array(
            'origin' => $this->input->post('origin'),
            'destination' => $this->input->post('destination'),
            'nama_penerima' => $this->input->post('nama_penerima'),
            'status_pengiriman' => $this->input->post('status_pengiriman'),
        );
        $this->M_transaksi->add_transaksi($data);
        redirect('C_transaksi');
    }

    public function deletetransaksi($resi){
        $this->M_transaksi->delete_transaksi($resi);
        redirect('C_transaksi');
    }

    public function updatetransaksi(){
        $id = $this->input->post('resi');
        $data = array(
            'origin' => $this->input->post('origin'),
            'destination' => $this->input->post('destination'),
            'nama_penerima' => $this->input->post('nama_penerima'),
            'status_pengiriman' => $this->input->post('status_pengiriman'),
        );
        $this->M_transaksi->update_transaksi($id,$data);
        redirect('C_transaksi');
    }

}
