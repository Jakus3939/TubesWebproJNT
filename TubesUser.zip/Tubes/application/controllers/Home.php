<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->model('M_Deliver');
	  }
	
	public function index()
	{
		$this->load->view('V_home');
	}

	public function checkresi () 
	{
		$billcode = $this->input->post('billcode');
		$where = [
			'resi' => $billcode
		];
		$data['resi'] = $this->M_home->getresi($where);
		$this->load->view('V_home', $data);
	}

	 public function deliverNow()
	{
		# code...
		$this->load->view('v_DeliverNow');
	}
	public function input_data(){
		// pengirim
		$nameSender = $this->input->post('nameSender');
		$phoneSender = $this->input->post('phoneSender');
		$citySender = $this->input->post('citySender');
		$adressSender = $this->input->post('adressSender');
		// penerima
		$nameReceipt = $this->input->post('nameReceipt');
		$phoneReceipt = $this->input->post('phoneReceipt');
		$cityReceipt = $this->input->post('cityReceipt');
		$adressReceipt = $this->input->post('adressReceipt');

		// barang
		$item = $this->input->post('item');
		$weight = $this->input->post('weight');

		$dataSender = array (
		  'nama_pengirim' => $nameSender,
		  'no_pengirim' => $phoneSender,
		  'kota_pengirim' => $citySender,
		  'alamat_pengirim' => $adressSender
		);

		$dataReceipt = array (
			'nama_penerima' => $nameReceipt,
			'no_penerima' => $phoneReceipt,
			'kota_penerima' => $cityReceipt,
			'alamat_penerima' => $adressReceipt
		  );

		  $barang = array (
			'nama_barang' => $item,
			'berat' => $weight,
		  );
		var_dump($barang);
		$insert = $this->M_Deliver->inputDeliver($dataSender,$dataReceipt,$barang);
		if($insert){
		  redirect(site_url('Home/index'));
		}else{
		  echo "<script>alert('Gagal Menambahkan Data');</script>";
		}
	  }
}