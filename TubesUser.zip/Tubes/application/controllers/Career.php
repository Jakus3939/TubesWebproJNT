<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Career extends CI_Controller {
    public function __construct()
    {
		parent::__construct();
		$this->load->model('M_career');
	}

	public function index()
	{
        $data['karir'] = $this->M_career->get_all();
        $this->load->view('V_career', $data);
	}

	public function formcreate(){
        $this->load->view('createCareer');
    }

    public function addcareer(){
        $data = array(
            'position' => $this->input->post('position'),
            'city' => $this->input->post('city'),
            'postdate' => $this->input->post('postdate'),
        );
        $this->M_career->add_career($data);
        redirect('career');
    }

    public function deletecareer($id_mebel){
        $this->M_career->delete_career($id_mebel);
        redirect('career');
    }

    public function updatecareer(){
        $id = $this->input->post('id_mebel');
        $data = array(
            'position' => $this->input->post('position'),
            'city' => $this->input->post('city'),
            'postdate' => $this->input->post('postdate'),
        );
        $this->M_career->update_career($id,$data);
        redirect('career');
    }
}