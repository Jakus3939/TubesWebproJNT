<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_admin extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_admin');
    }
    public function index()
    {
        $data['admin'] = $this->M_admin->get_all();
        $this->load->view('viewAdmin', $data);
    }

    public function createadmin(){
        $this->load->view('createAdmin');
    }

    public function addadmin(){
        $data = array(
            'username' => $this->input->post('username'),
            'password' => $this->input->post('password'),
        );
        $this->M_admin->add_admin($data);
        redirect('C_admin');
    }

    public function deleteadmin($id_admin){
        $this->M_admin->delete_admin($id_admin);
        redirect('C_admin');
    }

    public function updateadmin(){
        $id = $this->input->post('id_admin');
        $data = array(
            'username' => $this->input->post('username'),
            'password' => $this->input->post('password'),
        );
        $this->M_admin->update_admin($id,$data);
        redirect('C_admin');
    }

}
