<div class="modal fade" id="modal-update<?php echo $a['id_karir']; ?>">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <div class="modal-header">
        <h4 class="modal-title">Update Career - <?php echo $a['id_karir']; ?></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <div class="modal-body">
            <!--lengkapi action form untuk redirect ke home/update -->
            <form action="<?=base_url()?>home/update" method="POST" enctype="multipart/form-data">

            <div class="form-group">
                <label for="id_mebel">ID Mebel</label>
                <input class="form-control" type="text" name="id_mebel" value="<?php echo $a['id_karir'];?>" readonly/>
            </div>

            <div class="form-group">
                <label for="namabuku">Nama Mebel</label>
                <input class="form-control" type="text" name="namamebel" value="<?php echo $a['position'];?>" placeholder="Nama Mebel" required/>
            </div>

            <div class="form-group">
                <label for="kategori">Kategori</label>
                <input class="form-control" type="text" name="kategori" value="<?php echo $a['city'];?>" placeholder="Kategori" required/>
            </div>

            <div class="form-group">
                <label for="panjang">Panjang</label>
                <input class="form-control" type="number" name="panjang" value="<?php echo $a['postdate'];?>" placeholder="Panjang" required/>
            </div>

                <input type="submit" class="btn btn-primary btn-block" name="update" value="update" />

        </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer"></div>

    </div>
  </div>
</div>
