<html>
<head>
<style>
    table,tr,td{
        border : 1px solid;
        border-colapse:colapse;
    }
</style>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

    <div class="container mt-5">
        <h2>Data Mebel</h2>
        <div class="row">
            <div class="col-md-12">
            
                <div align="right" style="margin-right: 4%;margin-bottom: 2%">
                    <button class="btn btn-sm btn-primary action" onclick="location.href='<?php echo site_url('C_admin/createAdmin'); ?>'">Create</button>
                </div>
                <table class="table">
                    <tr>
                        <td>ID_Admin</td>
                        <td>Username</td>
                        <td>Password</td>
                    </tr>
                    <?php
                    foreach ($admin as $a){
                    ?>
                    <tr>
                        <!--Tampilkan data satu persatu pada tag td -->
                        <td><?=$a['id_admin']?></td>
                        <td><?=$a['username']?></td>
                        <td><?=$a['password']?></td>
                        <td>
                            <button class="btn btn-sm btn-danger action" data-toggle="modal" data-target="#modal-delete<?php echo $a['id_admin']; ?>">delete</button>
                            <?php include "deleteAdmin.php"; ?>
                            <button class="btn-sm btn btn-primary action" data-toggle="modal" data-target="#modal-update<?php echo $a['id_admin']; ?>">edit</button>
                            <?php include "editAdmin.php"; ?>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
        
            </div>

    </div>
</div>
</body>
</html>
