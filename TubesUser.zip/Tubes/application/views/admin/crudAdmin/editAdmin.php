<div class="modal fade" id="modal-update<?php echo $a['id_admin']; ?>">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <div class="modal-header">
        <h4 class="modal-title">Update Mebel - <?php echo $a['id_admin']; ?></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <div class="modal-body">
            <!--lengkapi action form untuk redirect ke home/update -->
            <form action="<?=base_url()?>index.php/C_admin/updateadmin" method="POST" enctype="multipart/form-data">

            <div class="form-group">
                <label for="id_admin">ID Admin</label>
                <input class="form-control" type="text" name="id_admin" value="<?php echo $a['id_admin'];?>" readonly/>
            </div>

            <div class="form-group">
                <label for="username">Username</label>
                <input class="form-control" type="text" name="username" value="<?php echo $a['username'];?>" placeholder="Username" required/>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input class="form-control" type="text" name="password" value="<?php echo $a['password'];?>" placeholder="Password" required/>
            </div>

                <input type="submit" class="btn btn-primary btn-block" name="update" value="update" />

        </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer"></div>

    </div>
  </div>
</div>
