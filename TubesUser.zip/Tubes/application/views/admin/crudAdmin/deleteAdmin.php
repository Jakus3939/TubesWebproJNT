<div class="modal fade" id="modal-delete<?php echo $a['id_admin']; ?>">
  <div class="modal-dialog modal-sm modal-dialog-centered">
    <div class="modal-content">


      <!-- Modal body -->
      <div class="modal-body">
        <div class="row jarak-modal">
          <div class="col-12">
            <h5 class="text-center modal-del">Are you sure?</h5>
          </div>
          <div class="col-12 text-center">
            
              <button type="button" class="btn btn-light lebar-but" data-dismiss="modal">No</button>
              &nbsp;&nbsp;&nbsp;
              <!--lengkapi onclick pada button yes untuk redirect ke home/deletemebel/'.$a['id_mebel']  -->
              <input type="submit" class="btn btn-dark lebar-but" onclick="location.href='<?php echo site_url('C_admin/deleteadmin/'.$a['id_admin']);?> '" value="Yes" />
          </div>
        </div>
      </div>


    </div>
  </div>
</div>