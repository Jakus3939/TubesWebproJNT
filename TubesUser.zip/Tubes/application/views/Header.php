<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>J&T EXPRESS</title>
    <!-- INCLUDE BOOTSTRAP CSS HERE -->
    <script type="text/javascript" src="<?= base_url(); ?>assets/js/jquery.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/js/bootstrap.bundle.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/js/bootstrap.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/js/bootstrap-select.js"></script>
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/bootstrap-select.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/bootstrap-spinner.css">
    <script type="text/javascript" src="<?= base_url(); ?>assets/js/jquery.spinner.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css">



</head>
<!-- <style>
    .dropdown {
      position: relative;
      display: inline-block;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #f9f9f9;
      min-width: 160px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
      padding: 12px 16px;
      z-index: 1;
    }

    .dropdown:hover .dropdown-content {
      display: block;
    }
</style> -->
<body class="bg-light">
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container">
            <div class="p pl-5">
                <a class="navbar-brand mr-5" href="<?php echo base_url('')?>"><img src="<?= base_url()?>assets/img/2.png" height="60" width="140"></a>
            </div>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto center">
                    <li class="nav-item active">
                        <a class="nav-link" href="<?php echo base_url('Home/index')?>"><img src="<?= base_url()?>assets/img/3.png" class="menu-icon"> Home <span class="sr-only"></span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo site_url('Home/deliverNow')?>"><img src="<?= base_url()?>assets/img/4.png" class="menu-icon"> Deliver Now</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle submenu" href="<?php echo site_url('')?>" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="<?= base_url()?>assets/img/5.png" class="menu-icon">
                            Express Service
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo site_url('')?>">Tariff Check</a>
                            <a class="dropdown-item" href="<?php echo site_url('')?>">Trace & Track</a>
                            <a class="dropdown-item" href="<?php echo site_url('')?>">Drop Point</a>
                            <a class="dropdown-item" href="<?php echo site_url('')?>">Prohibited</a>
                        </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle submenu" href="<?php echo site_url('')?>" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="<?= base_url()?>assets/img/6.png" class="menu-icon">
                            About Us
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo site_url('')?>">Contact Us</a>
                            <a class="dropdown-item" href="<?php echo site_url('')?>">Commitment</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo site_url('Career/index')?>"><img src="<?= base_url()?>assets/img/7.png" class="menu-icon"> Career</a>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <div class="switch" mr-top>
                        <a href="#" style="border-right: 1px solid #bbbbbb">EN</a>
                        <a href="#" style="border-right: 1px solid #bbbbbb">ID</a>
                        <a href="#">ZH</a>
                    </div>
                    <a href="<?php echo site_url('')?>" id="contact"><img src="<?= base_url()?>assets/img/8.png" height="80" width="120" alt="Test"></a>
                </ul>
            </div>
        </div>
    </nav>
