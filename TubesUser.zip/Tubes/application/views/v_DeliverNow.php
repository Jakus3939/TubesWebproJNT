<?php $this->load->view('Header') ?>

    <!-- CONTAINER -->
    <div class="bd-example">
        <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="3"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="<?= base_url()?>assets/img/home1.jpg" class="d-block w-100" alt="messi">
                    <div class="carousel-caption d-none d-md-block"></div>
                </div>
                <div class="carousel-item">
                    <img src="<?= base_url()?>assets/img/home2.jpg" class="d-block w-100" alt="verstappen">
                    <div class="carousel-caption d-none d-md-block"></div>
                </div>
                <div class="carousel-item">
                    <a href="<?= base_url('https://shopee.co.id/m/kompetisi-jnt')?>">
                        <img src="<?= base_url()?>assets/img/home3.jpg" class="d-block w-100" alt="verstappen">
                        <div class="carousel-caption d-none d-md-block"></div>
                    </a>
                </div>
                <div class="carousel-item">
                    <a href="<?= base_url('https://www.bukalapak.com/promo-detail/j-t-traktir-pelapak-ke-turki')?>">
                        <img src="<?= base_url()?>assets/img/home4.jpg" class="d-block w-100" alt="verstappen">
                        <div class="carousel-caption d-none d-md-block"></div>
                    </a>
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>

    <!-- CONTAINER -->
    <div class="container mt-5 mb-5">
        <div class="card">
        <center class='mt-5'>
            <h4 style='color: red;'>Deliver Now</h4> 
        </center>
            <div class='container'>
                <form action="<?php echo site_url().'/Home/input_data';?>" method="post">
                    <div class='row'>
                        <div class='col-md-6'>
                            <h4 style='color: red;'> <i class='fa fa-home'></i> Sender Information</h4> 
                                <div class="form-group">
                                    <div class='row'>
                                        <div class='col-md-2'>
                                            <label for="exampleInputEmail1">Name :</label>
                                        </div>
                                        <div class='col-md-10'>
                                            <input type="text" class="form-control" name='nameSender'>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class='row'>
                                        <div class='col-md-2'>
                                            <label for="exampleInputEmail1">Phone :</label>
                                        </div>
                                        <div class='col-md-10'>
                                            <input type="text" class="form-control" name='phoneSender'>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class='row'>
                                        <div class='col-md-2'>
                                            <label for="exampleInputEmail1">City :</label>
                                        </div>
                                        <div class='col-md-10'>
                                            <input type="text" class="form-control" name='citySender'>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class='row'>
                                        <div class='col-md-2'>
                                            <label for="exampleInputEmail1">Address </label>
                                        </div>
                                        <div class='col-md-10'>
                                            <textarea rows="4" cols="50" class="form-control" name='adressSender'> </textarea>
                                        </div>
                                    </div>
                                </div>
                        </div>
                        <div class='col-md-6'>
                            <h4 style='color: red;'><i class='fa fa-paper-plane'></i> Receipt Information</h4> 
                                <div class="form-group">
                                    <div class='row'>
                                        <div class='col-md-2'>
                                            <label for="exampleInputEmail1">Name :</label>
                                        </div>
                                        <div class='col-md-10'>
                                            <input type="text" class="form-control" name='nameReceipt'>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class='row'>
                                        <div class='col-md-2'>
                                            <label for="exampleInputEmail1">Phone :</label>
                                        </div>
                                        <div class='col-md-10'>
                                            <input type="text" class="form-control" name='phoneReceipt'>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class='row'>
                                        <div class='col-md-2'>
                                            <label for="exampleInputEmail1">City :</label>
                                        </div>
                                        <div class='col-md-10'>
                                            <input type="text" class="form-control" name='cityReceipt'>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class='row'>
                                        <div class='col-md-2'>
                                            <label for="exampleInputEmail1">Address </label>
                                        </div>
                                        <div class='col-md-10'>
                                            <textarea rows="4" cols="50" class="form-control" name='adressReceipt'> </textarea>
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>    
                    <div class='row mt-4'>
                        <div class='col-md-6'>
                            <h4 style='color: red;'><i class='fa fa-gift'></i> Package Information</h4> 
                                <div class="form-group">
                                    <div class='row'>
                                        <div class='col-md-2'>
                                            <label for="exampleInputEmail1">Item Name</label>
                                        </div>
                                        <div class='col-md-10'>
                                            <input type="text" class="form-control" name='item'>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class='row'>
                                        <div class='col-md-2'>
                                            <label for="exampleInputEmail1">Number</label>
                                        </div>
                                        <div class='col-md-10'>
                                            <input type="text" class="form-control" name='number'>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class='row'>
                                        <div class='col-md-2'>
                                            <label for="exampleInputEmail1">Goods Value</label>
                                        </div>
                                        <div class='col-md-10'>
                                            <input type="text" class="form-control" name='city'>
                                        </div>
                                    </div>
                                </div>
                        </div>
                        <div class='col-md-6 mt-4'>
                                <div class="form-group">
                                    <div class='row'>
                                        <div class='col-md-2'>
                                            <label for="exampleInputEmail1">weight :</label>
                                        </div>
                                        <div class='col-md-10'>
                                            <input type="number" class="form-control" name='weight'>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class='row'>
                                        <div class='col-md-2'>
                                            <label for="exampleInputEmail1">Remark</label>
                                        </div>
                                        <div class='col-md-10'>
                                            <textarea rows="4" cols="50" class="form-control" name='remark'> </textarea>
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                    <center>
                    <input type="submit" class="btn btn-danger mb-5" value='Deliver Now'/>
                    </center>
                </form>
            </div>        
        </div>
            
    </div>

    <style>
        .footer .container {
          border-top: 1px solid rgba(141,141,141,0.5);
        }
    </style>
    <div class="footer">
        <div class="top container">
            <div class="row container">
                <div class="col-md-3 col-sm-2 col-xs-12 service">
                    <h5>SERVICE</h5>
                    <ul>
                        <li><a href="<?php echo base_url('')?>">Home</a></li>
                        <li><a href="<?php echo base_url('')?>">Deliver Now</a></li>
                        <li><a href="<?php echo base_url('')?>">Express Services</a></li>
                        <li><a href="<?php echo base_url('')?>">About Us</a></li>
                        <li><a href="<?php echo base_url('')?>">Career</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-2 col-xs-12 information">
                    <h5>INFORMATION</h5>
                    <ul>
                        <li><a href="<?php echo base_url('')?>">FAQ</a></li>
                        <li><a href="<?php echo base_url('')?>">Terms of Delivery Service</a></li>
                        <li><a href="<?php echo base_url('')?>">Terms & Conditions</a></li>
                        <li><a href="<?php echo base_url('')?>">Privacy Policy</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-2 col-xs-12 touch">
                    <h5>GET IN TOUCH</h5>
                    <table>
                            <td class="address">Adress:</td>
                            <td>
                                Landmark Pluit<br>
                                Unit B1 Floor 8,9,10<br>
                                Jl. Pluit Selatan Raya, Jakarta Utara, 14450
                            </td>
                        </tr>
                        <tr>
                            <td class="phone">Phone:</td>
                            <td>
                                <a href="<?php echo base_url('')?>">021-8066-1888</a><br>
                            </td>
                        </tr>
                        <tr>
                            <td class="email">E-Mail:</td>
                            <td>
                                <a href="<?php echo base_url('')?>">
                                    <span class="call">jntcallcenter@jet.co.id</span>
                                </a><br>
                            </td>
                        </tr>
                    </table>
                </div>
                </div> 
            </div>
        </div>
        <div class="bottom container">
            <div class="container bg-danger">
                <div class="row container">
                    <div class="logo col-md-6 col-sm-6 gambar">
                        <a href="<?php echo base_url('')?>"><img src="assets/img/9.png"></a>
                    </div>
                    <div class="text-center col-md-6 col-sm-6 copyright">
                        Tugas Besar WEBPRO
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?= base_url()?> assets/js/jquery.min.js"></script>
    <script src="<?= base_url()?> assets/js/bootstrap.min.js"></script>
</body>
</html>