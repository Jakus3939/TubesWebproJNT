<?php $this->load->view('Header') ?>
    <!-- CAROUSEL -->
    <div class="bd-example ">
        <div class="p pt-5">
            <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                    <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
                    <li data-target="#carouselExampleCaptions" data-slide-to="3"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="<?= base_url()?>assets/img/home1.jpg" class="d-block w-100 imd-fluid" alt="messi">
                        <div class="carousel-caption d-none d-md-block"></div>
                    </div>
                    <div class="carousel-item">
                        <img src="<?= base_url()?>assets/img/home2.jpg" class="d-block w-100" alt="verstappen">
                        <div class="carousel-caption d-none d-md-block"></div>
                    </div>
                    <div class="carousel-item">
                        <a href="https://shopee.co.id/m/kompetisi-jnt">
                            <img src="<?= base_url()?>assets/img/home3.jpg" class="d-block w-100" alt="verstappen">
                            <div class="carousel-caption d-none d-md-block"></div>
                        </a>
                    </div>
                    <div class="carousel-item">
                        <a href="https://www.bukalapak.com/promo-detail/j-t-traktir-pelapak-ke-turki'">
                            <img src="<?= base_url()?>assets/img/home4.jpg" class="d-block w-100" alt="verstappen">
                            <div class="carousel-caption d-none d-md-block"></div>
                        </a>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>

    <!-- CONTAINER -->
    <div class="container">
        <div class="row pt-6 pb-6">
            <div class="col-6 text-center">
                <h4>Tariff Check</h4>
                <form method="POST" action="<?php echo site_url('')?>" accept-charset="UTF-8" id="tariff-check-form">
                    <input name="token" type="hidden" value=""/>
                    <div class="form-group form-inline tariff-city-input">
                        <label for="from">From:</label>
                        <select data-live-search="true" name="from" id="tariff-from" class="form-control selectpicker" 
                            data-info="province">
                        </select> 
                    </div>
                    <div class="form-group form-inline tariff-city-input">
                        <label for="to">To:</label>
                        <select data-live-search="true" name="to" id="tariff-to" class="form-control selectpicker" 
                            data-info="province">
                        </select> 
                    </div>
                    <div class="form-group form-inline tariff-weight-input">
                        <label for="tariff-weight">Weight:</label>
                        <div class="input-append spinner" data-trigger="spinner">
                            <input type="text" value="0" data-rule="quantity" style="width: 40px" name="weight"/>
                        </div>
                        <!-- <div class="spinner" data-trigger="spinner" id="spinner">
                            <input type="text" value="1" data-rule="quantity">
                            <div class="spinner-controls">
                                <a href="javascript:;" data-spin="up">+</a>
                                <a href="javascript:;" data-spin="down">-</a>
                            </div>
                        </div> -->
                    </div>
                    <div class="btn-wrapper">
                        <button type="submit" class="btn btn-danger" data-toggle="modal" data-target="#about">Check</button>
                    </div>
                </form>
            </div>
            <div class="col-6 text-center">
                <h4>Trace & Track</h4>
                <form method="POST" action="<?=site_url('home/checkresi')?>" accept-charset="UTF-8" id="track-package-form">
                    <input name="token" type="hidden" value="">
                    <div class="form-group">
                        <textarea class="form-control" rows="5" placeholder="E.g: 1234567890,9876543210" 
                            name="billcode" id="billcode">
                        </textarea>
                    </div>
                </form>
                <div class="note">
                    <p>Enter your waybill number (separated by comma). Available up to 10 waybills.</p>
                </div>
                <div class="btn-wrapper">
                    <button type="submit" class="btn btn-danger" data-toggle="modal" data-target="#about">Track</button>
                </div>
            </div>
        </div>
    </div>

    <!-- CONTAINER -->
    <div class="container">
        <div class="container tools-droppoint">
            <div class="droppoint-form">
                <div class="pin">
                    <i class="fa fa-map-o" aria-hidden="true"></i>
                </div>
                <div class="form">
                    <h3>Find local Drop Point in your area</h3>
                    <form method="POST" action="<?php echo site_url('')?>" accept-charset="UTF-8" id="droppoint-form" class="form-inline">
                        <input name="token" type="hidden" value=""/>
                        <div class="col-md-5 form-group">
                            <input class="form-control" placeholder="Select City" required="true" id="droppoint-city" 
                            name="droppoint-city" type="text" value="">
                        </div>
                        <div class="col-md-5 form-group">
                            <input class="form-control" placeholder="Select Area" required="true" id="droppoint-area" 
                            name="droppoint-area" type="text" value="">
                        </div>
                        <div class="col-md-2 form-group btn-wrapper">
                            <button type="submit" class="btn btn-danger">Go</button>
                        </div>
                    </form>
                </div>
            </div> 
        </div>
    </div>


    <!-- <div class="row">
        <div class="col-lg-4 col-sm-4 mb-4">
            <div class="card h-100">
                <a href="<?php echo base_url('')?>">
                    <h5>News</h5>
                </a>
                <div class="single-news">
                    <a href="http://www.jet.co.id/news/show/pengumuman-penundaan-proses-pengiriman-akibat-banjir-di-kalimantan-barat">
                        <img class="card-img-top" src="http://placehold.it/700x400" alt="">
                    </a>
                    <div class="card-body">
                        <h5 class="card-title">
                            <a href="<?php echo base_url('http://www.jet.co.id/news/show/pengumuman-penundaan-proses-pengiriman-akibat-banjir-di-kalimantan-barat')?>">
                                <span>Pengumuman Penundaan Proses Pengiriman Akibat Banjir di Kalimantan Barat</span>
                            </a>
                        </h5>
                        <div class="excerpt">
                            <p> Kepada YthPelanggan J&T Express di seluruh Indonesia, Bersama ini...</p>
                        </div>
                        <a class="read-more" href="<?php echo base_url('http://www.jet.co.id/news/news')?>">
                            <h6> > Read More</h6>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card h-100">
                <a href="<?php echo base_url('http://www.jet.co.id/news/events')?>">
                    <h5>Events</h5>
                </a>
                <div class="single-news">
                    <a href="#"><img class="card-img-top" src="http://placehold.it/700x400" alt=""></a>
                    <div class="card-body">
                        <h5 class="card-title">
                            <a href="<?php echo base_url('http://www.jet.co.id/news/show/antisipasi-harbolnas-12.12,-bersama-dengan-idea-j&t-express-partisipasi-kegiatan-workshop-optimizing-traffic-during-harb')?>">
                                <span>Antisipasi Harbolnas 12.12, Bersama dengan IdEA J&T Express Partisipasi Kegiatan Workshop Optimizing</span>
                            </a>
                        </h5>
                        <div class="excerpt">
                            <p> Jakarta, 22 November 2019 - Pertumbuhan Internet yang pesat...</p>
                        </div>
                        <a class="read-more" href="<?php echo base_url('http://www.jet.co.id/news/events')?>">
                            <h6> > Read More</h6>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card h-100">
                <a href="<?php echo base_url('http://www.jet.co.id/news/events')?>">
                    <h5>Employee of the Month</h5>
                </a>
                <div class="single-news">
                    <a href="#"><img class="card-img-top" src="http://placehold.it/700x400" alt=""></a>
                    <div class="card-body">
                        <h5 class="card-title">
                            <a href="<?php echo base_url('http://www.jet.co.id/news/show/raih-penghargaan,-tofik-buktikan-keterbatasan-bukanlah-hambatan')?>">
                                <span>Raih Penghargaan, Tofik Buktikan Keterbatasan Bukanlah Hambatan</span>
                            </a>
                        </h5>
                        <div class="excerpt">
                            <p> Memiliki kondisi yang tidak sama dengan orang pada umumnya,...</p>
                        </div>
                        <a class="read-more" href="<?php echo base_url('http://www.jet.co.id/news/employee-of-the-month')?>"><h6> > Read More</h6></a>
                    </div>
                </div>
            </div>
        </div>
    </div> -->


    <style>
        .footer .container {
          border-top: 1px solid rgba(141,141,141,0.5);
        }
    </style>
    <div class="footer">
        <div class="top container">
            <div class="row container">
                <div class="col-md-3 col-sm-2 col-xs-12 service">
                    <h5>SERVICE</h5>
                    <ul>
                        <li><a href="<?php echo site_url('')?>">Home</a></li>
                        <li><a href="<?php echo site_url('')?>">Deliver Now</a></li>
                        <li><a href="<?php echo site_url('')?>">Express Services</a></li>
                        <li><a href="<?php echo site_url('')?>">About Us</a></li>
                        <li><a href="<?php echo site_url('')?>">Career</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-2 col-xs-12 information">
                    <h5>INFORMATION</h5>
                    <ul>
                        <li><a href="<?php echo site_url('')?>">FAQ</a></li>
                        <li><a href="<?php echo site_url('')?>">Terms of Delivery Service</a></li>
                        <li><a href="<?php echo site_url('')?>">Terms & Conditions</a></li>
                        <li><a href="<?php echo site_url('')?>">Privacy Policy</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-2 col-xs-12 touch">
                    <h5>GET IN TOUCH</h5>
                    <table>
                            <td class="address">Adress:</td>
                            <td>
                                Landmark Pluit<br>
                                Unit B1 Floor 8,9,10<br>
                                Jl. Pluit Selatan Raya, Jakarta Utara, 14450
                            </td>
                        </tr>
                        <tr>
                            <td class="phone">Phone:</td>
                            <td>
                                <a href="<?php echo site_url('')?>">021-8066-1888</a><br>
                            </td>
                        </tr>
                        <tr>
                            <td class="email">E-Mail:</td>
                            <td>
                                <a href="<?php echo site_url('')?>">
                                    <span class="call">jntcallcenter@jet.co.id</span>
                                </a><br>
                            </td>
                        </tr>
                    </table>
                </div>
                <!-- <div class="col-md-3 col-sm-2 col-xs-12 social">
                    <h5>Stay Connected</h5>
                    <div>
                        <a href="https://www.facebook.com/jntexpressindonesia/" target="_blank" class="link-facebook">
                            <i class="fa fa-facebook-square" aria-hidden="true"></i>
                        </a>
                        <a href="https://www.youtube.com/channel/UCdL3-euNvJhMMBvEVVBg5pA" target="_blank" class="link-youtube">
                            <i class="fa fa-youtube-square" aria-hidden="true"></i>
                        </a>
                        <a href="https://twitter.com/jntexpressid" target="_blank" class="link-twitter">
                            <i class="fa fa-twitter-square" aria-hidden="true"></i>
                        </a>
                        <a href="https://www.instagram.com/jntexpressid/" target="_blank" class="link-instagram">
                            <i class="fa fa-instagram" aria-hidden="true"></i>
                        </a>
                    </div>
                </div> -->
            </div>
        </div>
        <div class="bottom container">
            <div class="container bg-danger">
                <div class="row container">
                    <div class="logo col-md-6 col-sm-6 gambar">
                        <a href="<?php echo site_url('')?>"><img src="assets/img/9.png"></a>
                    </div>
                    <div class="text-center col-md-6 col-sm-6 copyright">
                        Tugas Besar WEBPRO
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?= base_url()?> assets/js/jquery.min.js"></script>
    <script src="<?= base_url()?> assets/js/bootstrap.min.js"></script>
</body>
</html>