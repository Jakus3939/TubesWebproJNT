<?php $this->load->view('Header') ?>


    <!-- COROUSEL -->
    <div class="bd-example">
        <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="<?= base_url()?>assets/img/home1.jpg" class="d-block w-100" alt="messi">
                    <div class="carousel-caption d-none d-md-block"></div>
                </div>
            </div>
        </div>
    </div>





    <!-- Isi Career -->
    <div class="container mt-5">
        <h2>Career</h2>
        <div class="row">
            <div class="col-md-12">
            
                <!-- <div align="right" style="margin-right: 4%;margin-bottom: 2%">
                    <button class="btn btn-sm btn-primary action" onclick="location.href='<?php echo site_url('career/createCareer'); ?>'">Create</button>
                </div> -->
                <table class="table">
                    <tr>
                        <td>Position</td>
                        <td>City</td>
                        <td>Post Date</td>
                    </tr>
                    <?php
                    foreach ($karir as $a) {
                    ?>
                    <tr>
                        <!--Tampilkan data satu persatu pada tag td -->
                        <td><?=$a['position']?></td>
                        <td><?=$a['city']?></td>
                        <td><?=$a['postdate']?></td>
                    </tr>
                    <?php } ?>
                </table>

            </div>
        </div>
    </div>





    <!-- Footer -->
    <style>
        .footer .container {
          border-top: 1px solid rgba(141,141,141,0.5);
        }
    </style>
    <div class="footer">
        <div class="top container">
            <div class="row container">
                <div class="col-md-3 col-sm-2 col-xs-12 service">
                    <h5>SERVICE</h5>
                    <ul>
                        <li><a href="<?php echo site_url('')?>">Home</a></li>
                        <li><a href="<?php echo site_url('')?>">Deliver Now</a></li>
                        <li><a href="<?php echo site_url('')?>">Express Services</a></li>
                        <li><a href="<?php echo site_url('')?>">About Us</a></li>
                        <li><a href="<?php echo site_url('')?>">Career</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-2 col-xs-12 information">
                    <h5>INFORMATION</h5>
                    <ul>
                        <li><a href="<?php echo site_url('')?>">FAQ</a></li>
                        <li><a href="<?php echo site_url('')?>">Terms of Delivery Service</a></li>
                        <li><a href="<?php echo site_url('')?>">Terms & Conditions</a></li>
                        <li><a href="<?php echo site_url('')?>">Privacy Policy</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-2 col-xs-12 touch">
                    <h5>GET IN TOUCH</h5>
                    <table>
                            <td class="address">Adress:</td>
                            <td>
                                Landmark Pluit<br>
                                Unit B1 Floor 8,9,10<br>
                                Jl. Pluit Selatan Raya, Jakarta Utara, 14450
                            </td>
                        </tr>
                        <tr>
                            <td class="phone">Phone:</td>
                            <td>
                                <a href="<?php echo site_url('')?>">021-8066-1888</a><br>
                            </td>
                        </tr>
                        <tr>
                            <td class="email">E-Mail:</td>
                            <td>
                                <a href="<?php echo site_url('')?>">
                                    <span class="call">jntcallcenter@jet.co.id</span>
                                </a><br>
                            </td>
                        </tr>
                    </table>
                </div>
                <!-- <div class="col-md-3 col-sm-2 col-xs-12 social">
                    <h5>Stay Connected</h5>
                    <div>
                        <a href="https://www.facebook.com/jntexpressindonesia/" target="_blank" class="link-facebook">
                            <i class="fa fa-facebook-square" aria-hidden="true"></i>
                        </a>
                        <a href="https://www.youtube.com/channel/UCdL3-euNvJhMMBvEVVBg5pA" target="_blank" class="link-youtube">
                            <i class="fa fa-youtube-square" aria-hidden="true"></i>
                        </a>
                        <a href="https://twitter.com/jntexpressid" target="_blank" class="link-twitter">
                            <i class="fa fa-twitter-square" aria-hidden="true"></i>
                        </a>
                        <a href="https://www.instagram.com/jntexpressid/" target="_blank" class="link-instagram">
                            <i class="fa fa-instagram" aria-hidden="true"></i>
                        </a>
                    </div>
                </div> -->
            </div>
        </div>
        <div class="bottom container">
            <div class="container bg-danger">
                <div class="row container">
                    <div class="logo col-md-6 col-sm-6 gambar">
                        <a href="<?php echo site_url('')?>"><img src="assets/img/9.png"></a>
                    </div>
                    <div class="text-center col-md-6 col-sm-6 copyright">
                        Tugas Besar WEBPRO
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?= base_url()?> assets/js/jquery.min.js"></script>
    <script src="<?= base_url()?> assets/js/bootstrap.min.js"></script>

</body>
</html>
