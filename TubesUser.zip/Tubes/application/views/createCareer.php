<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register Admin</title>
    
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container mt-5">
    <h2>Input Data Mebel</h2>
    <div class="row">
        <div class="col-md-12">
         <!--Lengkapi action form untuk redirect ke fungsi yang ada di controller -->   
        <form action="<?=base_url()?>index.php/home/addmebel" method="POST" enctype="multipart/form-data">

            <div class="form-group">
                <label for="namabuku">ID_Karir</label>
                <input class="form-control" type="text" name="id_karir" required/>
            </div>

            <div class="form-group">
                <label for="kategori">Position</label>
                <input class="form-control" type="text" name="position" required/>
            </div>

            <div class="form-group">
                <label for="panjang">City</label>
                <input class="form-control" type="number" name="city" required/>
            </div>

            <div class="form-group">
                <label for="lebar">Post Date</label>
                <input class="form-control" type="number" name="postdate" required/>
            </div>
            <input type="submit" class="btn btn-primary btn-block" name="daftar" value="Create" required/>

        </form>
            
        </div>

    </div>
</div>

</body>
</html>