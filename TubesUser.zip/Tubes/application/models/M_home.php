<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_home extends CI_Model
{
	public function getresi($where) 
	{
		return $this->db->get_where('transaksi', $where);
	}
}