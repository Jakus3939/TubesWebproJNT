<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_transaksi extends CI_Model{
    
    public function get_all(){
        $data = $this->db->get('transaksi');
        return $data->result_array();
    }

    public function add_mebel($data){
        $this->db->insert('transaksi', $data);
    }

    public function delete_mebel($id){
        $this->db->where("resi", $id);
        $this->db->delete('transaksi');
    }

    public function updatemebel($id,$data){
        $this->db->where("resi", $id);
        $this->db->update('transaksi', $data);
    }
 }