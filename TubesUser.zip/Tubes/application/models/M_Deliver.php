<?php
class M_Deliver extends CI_Model
{
  public function inputDeliver($dataSender,$dataRecipt,$dataBarang){
    $insert1 = $this->db->insert('pengirim', $dataSender);
    $insert2 = $this->db->insert('penerima', $dataRecipt);
    $insert3 = $this->db->insert('barang', $dataBarang);
    if ($insert1 && $insert2 && $insert3){
      return TRUE;
    }else{
      return FALSE;
    }
  }
}