<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_career extends CI_Model{
    
    public function get_all(){
        $data = $this->db->get('karir');
        return $data->result_array();
    }

    public function add_mebel($data){
        $this->db->insert('karir', $data);
    }

    public function delete_career($id){
        $this->db->where("id_karir", $id);
        $this->db->delete('karir');
    }

    public function update_career($id,$data){
        $this->db->where("id_karir", $id);
        $this->db->update('karir', $data);
    }
 }