<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_admin extends CI_Model{
    
    public function get_all(){
        $data = $this->db->get('admin');
        return $data->result_array();
    }

    public function add_mebel($data){
        $this->db->insert('admin', $data);
    }

    public function delete_mebel($id){
        $this->db->where("id_admin", $id);
        $this->db->delete('admin');
    }

    public function updatemebel($id,$data){
        $this->db->where("id_admin", $id);
        $this->db->update('admin', $data);
    }
 }